# Ansible Collection - netology.yandex_cloud_elk

Documentation for the collection.

This collection includes module to create any file with any content which is located in plugins file. Also, it includes a simple role which is called test to implement module. Finally, it shows an example of a playbook site.yml which apply this role in a localhost.    